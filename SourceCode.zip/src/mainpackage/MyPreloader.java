package mainpackage;

import javafx.application.Preloader;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

//This class is responsible for the loading of the splashscreen
public class MyPreloader extends Preloader {
	private Stage preloaderStage;
	private Scene scene;

	//this method is called at first to show the layout of the stage
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		this.preloaderStage=primaryStage;
		preloaderStage.setTitle("Wheel Of Fortune");
        preloaderStage.setScene(scene);
        preloaderStage.initStyle(StageStyle.UNDECORATED);
        preloaderStage.centerOnScreen();
        preloaderStage.show();
	}
	
	
	@Override
	public void init() throws Exception{
		Parent root = FXMLLoader.load(getClass().getResource("splashscreen.fxml"));
		scene = new Scene(root);
	}
	

	@Override
	public void handleApplicationNotification(Preloader.PreloaderNotification info) {
		if(info instanceof ProgressNotification) {
			if(((ProgressNotification) info).getProgress()<0.3) {
				FXMLController.progress.setStyle("-fx-accent: purple");
			}
			else if(((ProgressNotification) info).getProgress()>0.3 && ((ProgressNotification) info).getProgress()<0.6) {
				FXMLController.progress.setStyle("-fx-accent: red");
			}
			else if(((ProgressNotification) info).getProgress()>0.6) {
				FXMLController.progress.setStyle("-fx-accent: green");
			}
			
			FXMLController.progress.setProgress(((ProgressNotification) info).getProgress());
		}
	}
	
	//this method handle the notification that is recieved
	@Override
	public void handleStateChangeNotification(Preloader.StateChangeNotification info) {
		StateChangeNotification.Type type=info.getType();
		
		switch(type) {
		//if the case is true then the splash screen is closed
		case BEFORE_START:
			System.out.println("before start");
			preloaderStage.hide();
			break;
		default:
			break;
		}
	}

}
