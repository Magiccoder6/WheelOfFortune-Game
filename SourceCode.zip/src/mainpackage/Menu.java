package mainpackage;


import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

//This class is responsible showing navigation for the different parts (menu)
public class Menu implements Initializable{
	private MediaPlay mp = new MediaPlay();

//Button to play game
    public void playButton(MouseEvent event) throws IOException {

    	mp.stopMenuSound();
        Parent root = FXMLLoader.load(getClass().getResource("scene.fxml"));
        javafx.scene.Scene scene = new Scene(root);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.setTitle("Wheel Of Fortune");
        window.centerOnScreen();
        window.show();

    }

    ////Button to goto option
    @FXML
    void options(MouseEvent event) throws IOException {
    	mp.stopMenuSound();
        Parent root = FXMLLoader.load(getClass().getResource("options.fxml"));
        javafx.scene.Scene scene = new Scene(root);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.setTitle("OPTIONS");
        window.centerOnScreen();
        window.show();

    }
    
    //Button to goto about page 
    @FXML
    void about(MouseEvent event) throws IOException {
    	mp.stopMenuSound();
    	 Parent root = FXMLLoader.load(getClass().getResource("about.fxml"));
         javafx.scene.Scene scene = new Scene(root);
         Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
         window.setScene(scene);
         window.setTitle("About");
         window.centerOnScreen();
         window.show();
    }

    //Buton to exit application
	@FXML
    void exit(MouseEvent event) {
			Platform.exit();
    }


	//Start play media when the class is open
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		mp.menuSound();
	}
}
