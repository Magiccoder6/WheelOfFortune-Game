package mainpackage;

import javafx.animation.RotateTransition;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.net.URL;
import java.util.*;

//This class is responsible for gameplay
public class Scene implements Initializable {
    @FXML
    private TextField t1;
    @FXML
    private TextField t11;
    @FXML
    private TextField t21;
    @FXML
    private TextField t31;
    @FXML
    private TextField t2;
    @FXML
    private TextField t12;
    @FXML
    private TextField t22;
    @FXML
    private TextField t32;
    @FXML
    private TextField t3;
    @FXML
    private TextField t13;
    @FXML
    private TextField t23;
    @FXML
    private TextField t33;
    @FXML
    private TextField t4;
    @FXML
    private TextField t14;
    @FXML
    private TextField t24;
    @FXML
    private TextField t34;
    @FXML
    private TextField t5;
    @FXML
    private TextField t15;
    @FXML
    private TextField t25;
    @FXML
    private TextField t35;
    @FXML
    private TextField t6;
    @FXML
    private TextField t16;
    @FXML
    private TextField t26;
    @FXML
    private TextField t36;
    @FXML
    private TextField t7;
    @FXML
    private TextField t8;
    @FXML
    private TextField t9;
    @FXML
    private TextField t10;
    @FXML
    private TextField t17;
    @FXML
    private TextField t18;
    @FXML
    private TextField t27;
    @FXML
    private TextField t37;
    @FXML
    private TextField t28;
    @FXML
    private TextField t38;
    @FXML
    private TextField t19;
    @FXML
    private TextField t29;
    @FXML
    private TextField t39;
    @FXML
    private TextField t20;
    @FXML
    private TextField t30;
    @FXML
    private TextField t40;
    @FXML
    private TextField b;

    @FXML
    private TextField c;
    @FXML
    private TextField d;
    @FXML
    private TextField f;
    @FXML
    private TextField g;
    @FXML
    private TextField h;
    @FXML
    private TextField j;
    @FXML
    private TextField k;
    @FXML
    private TextField l;
    @FXML
    private TextField m;
    @FXML
    private TextField n;
    @FXML
    private TextField p;
    @FXML
    private TextField q;
    @FXML
    private TextField r;
    @FXML
    private TextField s;
    @FXML
    private TextField t;
    @FXML
    private TextField v;
    @FXML
    private TextField w;
    @FXML
    private TextField x;
    @FXML
    private TextField y;
    @FXML
    private TextField z;
    @FXML
    private TextField a;
    @FXML
    private TextField e;
    @FXML
    private TextField i;
    @FXML
    private TextField o;
    @FXML
    private TextField u;
    @FXML
    private ImageView wheel;
    @FXML
    private RadioButton p3;
    @FXML
    private RadioButton p1;
    @FXML
    private RadioButton p2;
    @FXML
    private Label Player1;
    @FXML
    private Label Player2;
    @FXML
    private Label Player3;
    @FXML
    private Pane Container;
    @FXML
    private Pane Vows;
    @FXML
    private Label Ctg;
    @FXML
    private Label Name1;
    @FXML
    private Label Name2;
    @FXML
    private Label Name3;
    @FXML
    private ImageView SpinBtn;
    @FXML
    private ImageView r1;
    @FXML
    private ImageView r2;
    @FXML
    private ImageView r3;




    private int player1=0, player2=0, player3=0;
    private int GrandP1=0,GrandP2=0,GrandP3=0;
    private int WinnerTotal=0;
    private int card ;
    private int StageNumber=1;
    private int inc=0;
    private String[] StageColor={"#0000CD","#4B0082","#FF4500","#00FF7F","#FFD700"};

    private LinkedList<TextField> fields = new LinkedList<TextField>();
    private LinkedList<TextField> letters = new LinkedList<TextField>();
    private LinkedList<TextField> EnteredLetters = new LinkedList<>();
    private LinkedList<TextField> EnteredLetters1 = new LinkedList<>();
    private PriorityQueue <String> chosenLetters = new PriorityQueue<String>();
    private int angles[]={0,15,30,45,60,75,90,105,120,135,150,165,180,195,210,225,240,255,270,285,300,315,330,345,360};
    
    private Random gen = new Random();//random number generator
   
    private MediaPlay mediaPlay = new MediaPlay();

    private Categories ct = new Categories();
    private Alert al = new Alert(Alert.AlertType.INFORMATION);

    private  String[] Category ;//store the name read from a file

    //Method that is first call when the class is open
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        getNames();//get player names
        setCategory(); //set the category word to display

        saveTextFields();//save the textfields that will be used to the linkedlist
        getEditField();//save the textfield that has been edited to a linked list
        setLetterListener();//set a listener to the letters, and set the clicked letter to a queue

        boardSetter(Category[0]);//add a couple letters  to the board on row 1 according to the category
        boardSetter1(Category[1]);//add a couple letters  to the board on row 2 according to the category


    }

    public void setCategory(){
        if(StageNumber==1){
            Category =ct.getPerson();
            Ctg.setText("PERSON");
        }
        else if(StageNumber==2){
            Category =ct.getPlaces();
            Ctg.setText("PLACE");
        }
        else if(StageNumber==3){
            Category=ct.getThings();
            Ctg.setText("THING");
        }
    }
    public void newPuzzle(){
        //refresh screen   this function is call in the solve method
        mediaPlay.newPuzzleSound();//sound of new puzzle
        Category=null;
        EnteredLetters1.clear();
        EnteredLetters.clear();

        int color=gen.nextInt(StageColor.length);
        for(int i=0;i<fields.size();i++){
            fields.get(i).setStyle("-fx-control-inner-background: "+StageColor[color]);
            fields.get(i).clear();
            fields.get(i).setEditable(true);
        }

        for(int i=0;i<letters.size();i++){
            letters.get(i).setVisible(true);
        }

        StageNumber++;
        System.out.println(StageNumber);
        setCategory();

        getEditField();
        setLetterListener();

        boardSetter(Category[0]);
        boardSetter1(Category[1]);

    }

    public void boardSetter(String name){
        char[] ch = name.toCharArray();
        int pos=0;

            pos = gen.nextInt(Category[0].length() );
            fields.get(pos).setText(Character.toString(ch[pos]));
        fields.get(pos).setEditable(false);
            for(int i = 0; i< Category[0].length(); i++) {
                    fields.get(i).setStyle("-fx-control-inner-background: white");

            }

    }

    public void boardSetter1(String name){
        char[] ch = name.toCharArray();
        int pos=0;


        pos = gen.nextInt(Category[1].length() );
        fields.get(pos+11).setText(Character.toString(ch[pos]));
        fields.get(pos+11).setEditable(false);
        for(int i = 0; i< Category[1].length(); i++) {
            fields.get(i+11).setStyle("-fx-control-inner-background: white");

        }
    }

    public void setLetterListener(){
        for(int i=0;i<letters.size();i++){
            letters.get(i).setOnMouseClicked(event -> {
				// TODO Auto-generated method stub
				 final Node src = (Node) event.getSource();
			        String id = src.getId();
			            setLetter(id.toUpperCase());
			        src.setVisible(false);
			});
        }
    }

    public void setLetter(String id){
        SpinBtn.setDisable(false);

            boolean wrong = true;
            char[] ch = Category[0].toCharArray();
            char[] ch1 = Category[1].toCharArray();

        buyVowel(id);

            for (int j = 0; j < ch.length; j++) {
                if(!fields.get(j).getText().equals(id)) {
                    if (id.equals(Character.toString(ch[j]))) {
                        fields.get(j).setText(id);
                        mediaPlay.dingSound();//sound whenletter is selected
                        fields.get(j).setEditable(false);
                        chosenLetters.add(id);
                        if (!getVowels(id))
                            setTotal(card);
                        wrong = false;
                        Container.setDisable(true);
                        Vows.setDisable(true);

                    }
                }
                else{mediaPlay.buzzer();}
            }

            for (int j = 0; j < ch1.length; j++) {
                if(!fields.get(j+11).getText().equals(id)) {
                    if (id.equals(Character.toString(ch1[j]))) {
                        fields.get(j + 11).setText(id);
                        mediaPlay.dingSound();//sound when letter is selected
                        fields.get(j + 11).setEditable(false);
                        chosenLetters.add(id);
                        if (!getVowels(id))
                            setTotal(card);

                        wrong = false;

                        Container.setDisable(true);
                        Vows.setDisable(true);

                    }
                }
                else{mediaPlay.buzzer();}
            }

            if(wrong){
                    mediaPlay.buzzer();//sound if the letter is wrong
                Container.setDisable(true);
                Vows.setDisable(true);
                if(p1.isSelected()){
                    p1.setSelected(false);
                    p2.setSelected(true);
                    r1.setVisible(false);
                    r2.setVisible(true);

                }
                else if(p2.isSelected()){
                    p2.setSelected(false);
                    p3.setSelected(true);
                    r2.setVisible(false);
                    r3.setVisible(true);

                }
                else if(p3.isSelected()){
                    p3.setSelected(false);
                    p1.setSelected(true);
                    r3.setVisible(false);
                    r1.setVisible(true);

                }

            }
    }

    public void saveTextFields(){
        fields.add(t1);
        fields.add(t2);
        fields.add(t3);
        fields.add(t4);
        fields.add(t5);
        fields.add(t6);
        fields.add(t7);
        fields.add(t8);
        fields.add(t9);
        fields.add(t10);
        fields.add(t11);
        fields.add(t12);
        fields.add(t13);
        fields.add(t14);
        fields.add(t15);
        fields.add(t16);
        fields.add(t17);
        fields.add(t18);
        fields.add(t19);
        fields.add(t20);
        fields.add(t21);
        fields.add(t22);
        fields.add(t23);
        fields.add(t24);
        fields.add(t25);
        fields.add(t26);
        fields.add(t27);
        fields.add(t28);
        fields.add(t29);
        fields.add(t30);
        fields.add(t31);
        fields.add(t32);
        fields.add(t33);
        fields.add(t34);
        fields.add(t35);
        fields.add(t36);
        fields.add(t37);
        fields.add(t38);
        fields.add(t39);
        fields.add(t40);

        letters.add(a);
        letters.add(b);
        letters.add(c);
        letters.add(d);
        letters.add(e);
        letters.add(f);
        letters.add(g);
        letters.add(h);
        letters.add(i);
        letters.add(j);
        letters.add(k);
        letters.add(l);
        letters.add(m);
        letters.add(n);
        letters.add(o);
        letters.add(p);
        letters.add(q);
        letters.add(r);
        letters.add(s);
        letters.add(t);
        letters.add(u);
        letters.add(v);
        letters.add(w);
        letters.add(x);
        letters.add(y);
        letters.add(z);

    }

    //Randomly select a number for card selection
    public int wheelData(){
        int cardz = gen.nextInt(angles.length);
       // System.out.println(angles[cardz]);
        return angles[cardz];


    }

    public void setTotal(int card){
        switch (card){
            case 15:
                players(600);
                break;
            case 30:
                players(300);
                break;
            case 45:
                players(700);
                break;
            case 60:
                players(450);
                break;
            case 75:
                players(350);
                break;
            case 90:
                players(800);
                break;
            case 105://lose a turn

                break;
            case 120:
                players(300);
                break;
            case 135:
                players(400);
                break;
            case 160:
                players(600);
                break;
            case 165://bankrupt

                break;
            case 180:
                players(900);
                break;
            case 195:
                players(850);
                break;
            case 210:
                players(500);
                break;
            case 225:
                players(900);
                break;
            case 240:
                players(300);
                break;
            case 255:
                players(400);
                break;
            case 270:
                players(550);
                break;
            case 285://bankrupt

                break;
            case 300:
                players(500);
                break;
            case 315:
                players(300);
                break;
            case 330:
                players(600);
                break;
            case 345:
                players(300);
                break;
            case 360:
                players(2500);
                break;
        }
    }

    public void players(int price){

        if(p1.isSelected()){
            player1+=price;
            Player1.setText(Integer.toString(player1));
        }

        else if(p2.isSelected()){
            player2+=price;
            Player2.setText(Integer.toString(player2));
        }

        else if(p3.isSelected()){
            player3+=price;
            Player3.setText(Integer.toString(player3));
        }

    }

    public void buyVowel(String id){

        if(getVowels(id)) {
            if (p1.isSelected()) {
                    player1 = player1 - 250;
                    Player1.setText(Integer.toString(player1));


            } else if (p2.isSelected()) {

                    player2 = player2 - 250;
                    Player2.setText(Integer.toString(player2));


            } else if (p3.isSelected()) {

                    player3 = player3 - 250;
                    Player3.setText(Integer.toString(player3));

            }
        }

    }
    public boolean getVowels(String id){
        boolean check=false;
        switch (id){
            case "A":
            case "E":
            case "I":
            case "O":
            case "U":

                check=true;
                break;
        }
        return check;
    }

    @FXML
    public void spin(MouseEvent event) {
        SpinBtn.setDisable(true);
        card=wheelData();
        int cycle=gen.nextInt((3-2)+1)+2;//generate a number between 2-3 for number of cycles
        System.out.println(((cycle*360)+card)/15+" = # of spaces moved");
        System.out.println(cycle);
        System.out.println(card);
       
        mediaPlay.spinning();//wheel spinning sound


        RotateTransition rt = new RotateTransition(Duration.seconds(17),wheel);
        rt.setFromAngle(0);
        rt.setToAngle(card+(cycle*360));
        rt.setDelay(Duration.seconds(0));
        rt.setRate(6);
        rt.play();

        if(card!=105 || card!=165 || card!=285) {//bankrupt or lose a turn
            Container.setDisable(false);
            Vows.setDisable(false);
        }

        if(card==105){
            SpinBtn.setDisable(false);
            mediaPlay.buzzer();
            Container.setDisable(true);
            Vows.setDisable(true);

            if(p1.isSelected()){
                p1.setSelected(false);
                p2.setSelected(true);
                r1.setVisible(false);
                r2.setVisible(true);
            }
            else if(p2.isSelected()){
                p2.setSelected(false);
                p3.setSelected(true);
                r2.setVisible(false);
                r3.setVisible(true);
            }
            else if(p3.isSelected()){
                p3.setSelected(false);
                p1.setSelected(true);
                r3.setVisible(false);
                r1.setVisible(true);
            }
        }//lose a turn

        if(card==165 || card==285){//bankrupt
            SpinBtn.setDisable(false);
           mediaPlay.bankruptSound();//play bankrupt sound
            Container.setDisable(true);
            Vows.setDisable(true);

            if(p1.isSelected()){
                p1.setSelected(false);
                p2.setSelected(true);
                r1.setVisible(false);
                r2.setVisible(true);
                player1=0;
                Player1.setText("0");
                players(0);
            }
            else if(p2.isSelected()){
                p2.setSelected(false);
                p3.setSelected(true);
                r2.setVisible(false);
                r3.setVisible(true);
                player2=0;
                Player2.setText("0");
                players(0);
            }
            else if(p3.isSelected()){
                p3.setSelected(false);
                p1.setSelected(true);
                r3.setVisible(false);
                r1.setVisible(true);
                player3=0;
                Player3.setText("0");
                players(0);
            }
        }

        //check for vowel allowance
        if (p1.isSelected()) {
            if(player1<250)
                Vows.setDisable(true);


        } else if (p2.isSelected()) {
            if(player2<250)
                Vows.setDisable(true);


        } else if (p3.isSelected()) {
            if(player3<250)
                Vows.setDisable(true);

        }

    }

    @FXML
    public void solvePuzzle(MouseEvent event) throws IOException {
        String text1[] = new String[Category[0].length()];
        String text2[] = new String[Category[1].length()];
        StringBuffer sb = new StringBuffer();
        StringBuffer sb1 = new StringBuffer();
        String name1,name2= "";


        for(int i = 0; i< Category[0].length(); i++) {
            text1[i]=fields.get(i).getText().toUpperCase();
            sb.append(text1[i]);
        }
        for(int i = 0; i< Category[1].length(); i++) {
            text2[i]=fields.get(i+11).getText().toUpperCase();
            sb1.append(text2[i]);
        }
            name1=sb.toString();
            name2=sb1.toString();

            //if puzzle is solved correctly
            if(name1.equals(Category[0]) && name2.equals(Category[1])){
                mediaPlay.solve();
                inc++;

                if(!p1.isSelected()){
                    player1=0;
                    Player1.setText(Integer.toString(player1));
                }
                else {
                    GrandP1 += player1+1000;
                    Player1.setText("0");
                    roundWinner(inc,1);
                    player1=0;
                }

                if(!p2.isSelected()){
                    player2=0;
                    Player2.setText(Integer.toString(player2));
                }
                else {
                    GrandP2 += player2+1000;
                    Player2.setText("0");
                    roundWinner(inc,2);
                    player2=0;
                }

                if(!p3.isSelected()){
                    player3=0;
                    Player3.setText(Integer.toString(player3));
                }
                else {
                    GrandP3 += player3+1000;
                    Player3.setText("0");

                    roundWinner(inc,3);
                    player3=0;
                }

                //check for last round
                if(StageNumber==3){
                    inc=0;

                    Alert al = new Alert(Alert.AlertType.CONFIRMATION);
                    al.setTitle("END OF GAME");
                    al.setHeaderText("Congratulation you Won!!!");
                    al.setContentText("Name: "+winner()+" "+"Money: $"+WinnerTotal);
                    ButtonType quit = new ButtonType("QUIT", ButtonBar.ButtonData.CANCEL_CLOSE);
                    ButtonType replay = new ButtonType("PLAY AGAIN",ButtonBar.ButtonData.CANCEL_CLOSE);

                    al.getButtonTypes().setAll(quit,replay);
                    Optional<ButtonType> result = al.showAndWait();

                    if(result.get()==quit){
                        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
                        javafx.scene.Scene scene = new javafx.scene.Scene(root);
                        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
                        window.setScene(scene);
                        window.setTitle("Main Menu");
                        window.centerOnScreen();
                        window.show();
                    }
                    else if(result.get()==replay){
                        resetPlayers();
                        StageNumber=0;
                    }

                    player1=0;
                    player2=0;
                    player3=0;
                    GrandP1=0;
                    GrandP2=0;
                    GrandP3=0;

                }

                    Container.setDisable(true);
                    Vows.setDisable(true);
                    newPuzzle();

            }

            //if word is incorrect
            else{
                mediaPlay.buzzer();

                 for(int i=0;i<EnteredLetters.size();i++){
                   EnteredLetters.get(i).clear();

                 }
                for(int j=0;j<EnteredLetters1.size();j++){
                    EnteredLetters1.get(j).clear();
                }

                switchPlayer();//switch player if they solve the puzzle incorrectly
                Container.setDisable(true);
                Vows.setDisable(true);
                SpinBtn.setDisable(false);

            }

    }

    public void getEditField(){


        try {
            for(int i = 0; i< Category[0].length(); i++) {

                //Converts texts to uppercase
                fields.get(i).setTextFormatter(new TextFormatter<Object>(change -> {
                    change.setText(change.getText().toUpperCase());
                    return change;
                }));

                int finalI = i;
                fields.get(i).addEventFilter(KeyEvent.KEY_TYPED, new EventHandler<KeyEvent>() {
                    @Override
                    public void handle(KeyEvent keyEvent) {

                        EnteredLetters.add(fields.get(finalI));

                    }
                });

            }
        } catch (Exception ex) {
            System.out.println("Empty Array");
        }


        try {
            //row 2 on screen
            for(int i = 0; i< Category[1].length(); i++) {

                //Converts texts to uppercase
                fields.get(i+11).setTextFormatter(new TextFormatter<Object>(change -> {
                    change.setText(change.getText().toUpperCase());
                    return change;
                }));

                int finalI = i+11;
                fields.get(i+11).addEventFilter(KeyEvent.KEY_TYPED, new EventHandler<KeyEvent>() {
                    @Override
                    public void handle(KeyEvent keyEvent) {

                        EnteredLetters1.add(fields.get(finalI));

                    }
                });

            }
        } catch (Exception ex) {
            System.out.println("Empty Array!!!");
        }
    }

    public void switchPlayer(){
        if(p1.isSelected()){
            p1.setSelected(false);
            p2.setSelected(true);
            r1.setVisible(false);
            r2.setVisible(true);
        }
        else if(p2.isSelected()){
            p2.setSelected(false);
            p3.setSelected(true);
            r2.setVisible(false);
            r3.setVisible(true);
        }
        else if(p3.isSelected()){
            p3.setSelected(false);
            p1.setSelected(true);
            r3.setVisible(false);
            r1.setVisible(true);
        }

    }

    public String winner(){
        String name;
        if(GrandP1>GrandP2 && GrandP1>GrandP3){
            name=Name1.getText();
            WinnerTotal=GrandP1;
        }
        else if(GrandP2>GrandP1 && GrandP2>GrandP3){
            name=Name2.getText();
            WinnerTotal=GrandP2;
        }
        else if(GrandP3>GrandP2 && GrandP3>GrandP1){
            name=Name3.getText();
            WinnerTotal=GrandP3;
        }
        else{
            name="NO WINNER!!!";
        }
        return name;

    }

    public void resetPlayers(){
        p1.setSelected(true);
        r1.setVisible(true);
        p2.setSelected(false);
        r2.setVisible(false);
        p3.setSelected(false);
        r3.setVisible(false);
    }

    public void roundWinner(int round,int player){
        al.setHeaderText("Round "+round+" Winner!!!");
        if(player==1){
            al.setContentText("Name: "+getName1().getText()+"\n Total: "+GrandP1);
        }

        else if(player==2){
            al.setContentText("Name: "+getName2().getText()+"\n Total: "+GrandP2);
        }

        else if(player==3){
            al.setContentText("Name: "+getName3().getText()+"\n Total: "+GrandP3);
        }
        al.showAndWait();
    }

    public void getNames(){
    	Options op = new Options();
    	String[] names = op.getNames();
    	
    	if(names!=null) {
    		 Name1.setText(names[0]);
             Name2.setText(names[1]);
             Name3.setText(names[2]);
    	}
    	

    	else{
                Name1.setText("P1");
                Name2.setText("P2");
                Name3.setText("P3");
            }
        
    }



    public Label getName1() {
        return Name1;
    }

    public Label getName2() {
        return Name2;
    }

    public Label getName3() {
        return Name3;
    }


}
