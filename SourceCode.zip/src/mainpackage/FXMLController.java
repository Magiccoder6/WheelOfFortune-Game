package mainpackage;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ProgressBar;

//This class is responsible to set the recieved values to the progress bar of the splash screen
public class FXMLController implements Initializable{
	 @FXML
	    private ProgressBar bar;
	 
	 public static ProgressBar progress;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		//set the progress bar from fxml to a new assign progress bar variable
		progress=bar;
	
	}
	 
	 

}
