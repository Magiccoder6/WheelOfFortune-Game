package mainpackage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.ScaleTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

//This class is responsible for for sowing information about developers
public class About implements Initializable{
	@FXML
    private ImageView pog;

    @FXML
    private ImageView shem;
    
  
 
    //when the menu button is clicked, the menu is shown
	 @FXML
	    void menu(MouseEvent event) throws IOException {
		 //assign the fxml file reference to the parent variable root
		 Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
		 //after the resource from the fxml files a accessed, then it is assign to a scene
	        javafx.scene.Scene scene = new Scene(root);
	        //the scence is then assign to a stage variable called window
	        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
	        window.setScene(scene);
	        window.setTitle("Main Menu");
	        window.centerOnScreen();
	        window.show();

	    }

	 //this function is call first when the class is opened
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
		
			//transition by scale for the the image, the duration and the node is set to constructor
			ScaleTransition sc = new ScaleTransition(Duration.seconds(3),shem);
			sc.setByX(0.1f);
			sc.setByY(0.1f);
			sc.setCycleCount(100);
			sc.setAutoReverse(true);
			sc.play();
			
			ScaleTransition sc1 = new ScaleTransition(Duration.seconds(3),pog);
			sc1.setByX(0.1f);
			sc1.setByY(0.1f);
			sc1.setCycleCount(100);
			sc1.setAutoReverse(true);
			sc1.play();
			
	
		
		
	}

}
