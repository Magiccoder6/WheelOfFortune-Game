package mainpackage;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

//This class is responsible for reading and sending categories
public class Categories {
	//linked list to store the categories
    private LinkedList<String> Persons = new LinkedList<String>();
    private LinkedList<String> Places = new LinkedList<String>();
    private LinkedList<String> Things = new LinkedList<String>();

    private Scanner sc;
    private Random rn = new Random();
    private Splashscreen ss = new Splashscreen();
     
    
    
    //this function read persons name from text file
    public void readPerson()  {
    	
        String tings = ss.getFolder().concat("/Game/categories/persons.txt");
      	 File things = new File(tings);
      	 System.out.println(tings);
          try {
			sc = new Scanner(things);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        

        while(sc.hasNext()){
            try {
                Persons.add(sc.next());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    
    //get a  name from the persons linkedlist
    public String[] getPerson(){
        Persons.clear();
        readPerson();
        
        //a random name is recieved from the linkedlist then get stored to name
        String name = Persons.get(rn.nextInt(Persons.size()));
        //the name is separated then get stored to an array individually
        String word[] = name.split("_");

        return word;//the array is returned
    }

    public void readPlaces(){
    	
        String tings = ss.getFolder().concat("/Game/categories/places.txt");
   	 File things = new File(tings);
       try {
		sc = new Scanner(things);
	} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}

        while(sc.hasNext()){
            try {
                Places.add(sc.next());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public String[] getPlaces(){
        Persons.clear();
        readPlaces();

        String name = Places.get(rn.nextInt(Places.size()));

        String word[] = name.split("_");

        System.out.println(word);

        return word;
    }

    public void readThings(){
    	String tings = ss.getFolder().concat("/Game/categories/things.txt");
    	 File things = new File(tings);
        try {
			sc = new Scanner(things);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

        while(sc.hasNext()){
            try {
                Things.add(sc.next());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    public String[] getThings(){
        Things.clear();
        readThings();

        String name = Things.get(rn.nextInt(Things.size()));

        String word[] = name.split("_");

        System.out.println(word);

        return word;
    }
}
