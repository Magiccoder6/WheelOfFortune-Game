package mainpackage;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;

//This class is responsible for adding player names
public class Options  {
    @FXML
    private TextField player1;

    @FXML
    private TextField player2;

    @FXML
    private TextField player3;
    
    private static String[] names = new String[3];
    
    

//This button click goes back to the menu
    public void backToMainMenu(javafx.scene.input.MouseEvent event) throws IOException {
    	saveNames();
        Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
        javafx.scene.Scene scene = new Scene(root);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.setTitle("Main Menu");
        window.centerOnScreen();
        window.show();
    }

    //Get the players names from input fields and save them to a array
    public void saveNames() {
    	names[0]=player1.getText();
    	names[1]=player2.getText();
    	names[2]=player3.getText();
    }
    
    //Get the name array
    public String[] getNames() {
    	return names;
    }

	
}
