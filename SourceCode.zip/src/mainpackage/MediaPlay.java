package mainpackage;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.util.Duration;

import java.io.File;


//This class is resposible for all media activities (play sounds)
public class MediaPlay {
    @FXML
    private MediaView mv;
    private MediaPlayer mp;
    private Media me;

    public Thread t1;
    @FXML
    public ImageView SBtn;
    
    Splashscreen ss = new Splashscreen();

   
    //play a sound when the fuction is called
    public void bankruptSound(){
    	//assign the mp3 file path to string path variable
        String path = new File(ss.getFolder().concat("/Game/bankrupt.mp3")).getAbsolutePath();
        //convert the file path to string then add it as media constructor
        me= new Media(new File(path).toURI().toString());
        //add media class to mediaplayer consructor
        mp=new MediaPlayer(me);
        mp.play();//play media
        
    }
    
    public void menuSound() {
    	String path = new File(ss.getFolder().concat("/Game/menusound.mp3")).getAbsolutePath();
        me= new Media(new File(path).toURI().toString());
        mp=new MediaPlayer(me);
        //loop sound until it is requested to stop
        mp.setOnEndOfMedia(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				mp.seek(Duration.ZERO);
			}
        	
        });
        mp.play();
    }
    
    public void stopMenuSound() {
        mp.stop();
    }

    public void spinning(){
        String path = new File(ss.getFolder().concat("/Game/spinning.mp3")).getAbsolutePath();
        me= new Media(new File(path).toURI().toString());
        mp=new MediaPlayer(me);
        mp.setStopTime(Duration.seconds(7));
        mp.play();
    }

    public void dingSound(){
        String path = new File(ss.getFolder().concat("/Game/Ding.mp3")).getAbsolutePath();
        me= new Media(new File(path).toURI().toString());
        mp=new MediaPlayer(me);
        mp.play();
    }

    public void buzzer(){
        String path = new File(ss.getFolder().concat("/Game/Buzzer.mp3")).getAbsolutePath();
        me= new Media(new File(path).toURI().toString());
        mp=new MediaPlayer(me);
        mp.play();
    }


    public void solve(){
        String path = new File(ss.getFolder().concat("/Game/solve.mp3")).getAbsolutePath();
        me= new Media(new File(path).toURI().toString());
        mp=new MediaPlayer(me);
        mp.play();
    }

    public void newPuzzleSound(){
        String path = new File(ss.getFolder().concat("/Game/Reveal.mp3")).getAbsolutePath();
        me= new Media(new File(path).toURI().toString());
        mp=new MediaPlayer(me);
        mp.play();
    }


}
